import java.util.Random;
import java.util.Scanner;

public class Grouplab4 

{
	public static void main(String[] args) 
	{
		int lottery [] = new int [5];
		int user [] = new int [lottery.length];
		
		for (int a = 0; a < lottery.length ; a++)
		{
			Random rnum = new Random();
			int randomNumber = rnum.nextInt(10);
			lottery[a] = randomNumber;
		}
		
		for (int a = 0; a < lottery.length; a++)
		{
			System.out.print("Enter number  "   + (a+1) + " " );
			Scanner in = new Scanner(System.in);
			user[a] = in.nextInt();
		}
		
		int correct = 0;
		
		for (int a = 0; a < lottery.length; a++)
		{
			if (lottery[a] == user[a])
			{
				correct++;
			}
		}
		
		if (correct == lottery.length)
		{
			System.out.println("You won the lottery " );
			System.out.println("The winning number were  "  + lottery[0] + " " +  lottery[1] + " " + lottery[2] + " " + lottery[3]
					+ " " +  lottery[4]);
		}
		else 
		{
			System.out.println("You lost the lottery " );
			System.out.println("You got  "  + correct + "  correct!   " );
			System.out.println("The winning number was  "  + lottery[0] + " " +  lottery[1] + " " + lottery[2] + " " + lottery[3]
					+ " " +  lottery[4]);
		}
	}
}
