import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class main {
	
	/*public static void main(String[] argy) throws Exception {
	
		UIManager.put("OptionPane.minimumSize",new Dimension(900,700));
		
		JFrame fname = new JFrame();
		
		String message = "message";
		
		int answer = JOptionPane.showConfirmDialog(fname, message);
		
		if (answer == JOptionPane.YES_OPTION){
			
			//User clicked yes
			
		} else if (answer == JOptionPane.NO_OPTION){
			
			//User clicked NO
			
		}*/
		
	
		/*public static void PredictRaise(double salary) {
			
			
			
			double newSalary;
			String sal;
			final double Raise_Rate = 1.10;
			newSalary = salary * Raise_Rate;
			sal = JOptionPane.showInputDialog(null, "Enter Salary: ");
			salary = Double.parseDouble(sal);
			JOptionPane.showMessageDialog(null, "Current Salary: " + salary);
			JOptionPane.showMessageDialog(null, "Salary After Raise: " + newSalary);

		}*/
	
		
	public static void main(String[] a){
		
		UIManager.put("OptionPane.minimumSize",new Dimension(900,700));
		
		JFrame fname = new JFrame();
		
		String biglist[] = new String[30];
		
		for (int i = 0; i < biglist.length; i++){
			
			biglist[i] = Integer.toString(i);
		}
		
		JOptionPane.showInputDialog(fname, "Pick a Printer", "Input", JOptionPane.QUESTION_MESSAGE, 
				null, biglist, "TEST" );
	}
	
}
	
			
		
	
	

