import java.util.Scanner;
public class Project3
{
		
	public static void printTriangle(int n)
	{
	    for (int a = 0; a < n; a++) 
	    {
	        for (int b = a; b < n; b++) 
	        {
	            System.out.print(" ");
	        }
	        for (int c = 0; c <= a; c++) 
	        {
	           
	                System.out.print("*");
	            System.out.print(" ");
	        }
	        System.out.println("");
	    } 
	}
	public static void printStar(int n) 
	{
		int a, b, c;
		for(a=1;a<=n;a++)
		{
			for(b=a;b<n;b++)
		{
				System.out.print(" ");
		}
			for(c=1;c<(a*2);c++)
		{
				System.out.print("*");
		}
			System.out.println();
		}
			for(a=n;a>=1;a--)
		{
				for(b=n;b>a;b--)
		{
					System.out.print(" ");
		}
				for(c=1;c<(a*2);c++)
		{
					System.out.print("*");
		}
				System.out.println();
		}
	}
	public static void printCircle(int n)
		{
	    	for (int a = -n; a <= n; a++) 
	    	{
	    		for (int b = -n; b <= n; b++) 
	    		{
	    			if (a*a + b*b <= n*n) 
	    				System.out.print("* ");
	    			else 
	    				System.out.print("  ");
	    		}
	        System.out.println();
	    	}
	}
	public static void printBowtie(int n)
	{
	    for (int a = -n; a <= n; a++) 
	    {
	        for (int b = -n; b <= n; b++) 
	        {
	            if (a*a <= b*b) 
	            	System.out.print("* ");
	            else 
	            	System.out.print("  ");
	        }
	        System.out.println();
	    }
	}
		public static void main(String[] args) 
	{
			boolean loop = false;
			int choice = 0;
			
			while (loop == false)
			{
				System.out.println( " Shapes Menu  ");
				System.out.println( " 1 Triangle ");
				System.out.println( " 2 Star ");
				System.out.println( " 3 Circle");
				System.out.println( " 4 Bow tie ");
				System.out.println(" 5 Exit ");
				
				Scanner newbuild = new Scanner(System.in);
				choice = newbuild.nextInt();
				
				if (choice <= 4 && choice >= 1 ){
		
				Scanner newbuilder = new Scanner(System.in);
				System.out.print( " Specify the range of symbols ");
				int n = newbuilder.nextInt();
				
				switch (choice) {
							case 1:
								printTriangle(n);
								break;
							case 2:
								printStar(n);
								break;
							case 3:
								printCircle(n);
								break;
							case 4:
								printBowtie(n);
								break;
							case 5:
							default:
								System.out.print(" no shape to print ");
							break;
										
								}
				}
				else{
					loop = true;
				}
				
				
			}
	
			
	}
}