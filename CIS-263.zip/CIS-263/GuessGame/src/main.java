import java.awt.Color;

import java.awt.Dimension;
import java.awt.Font;
import java.util.Random;
import java.util.regex.Pattern;
import java.awt.*;

import javax.management.timer.Timer;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

public class main {

	public static void main(String[] args){
		
		// Appearance (Window Size, TextColor, etc.)
		UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Verdana", Font.BOLD, 42)));
		UIManager.put("OptionPane.messageForeground", Color.DARK_GRAY);
		UIManager.put("TextField.font", new FontUIResource(new Font("Verdana", Font.BOLD, 32)));
		UIManager.put("OptionPane.minimumSize",new Dimension(1000,600));
							
		//variables
		int randomNumber = 0;
		int playerChoice;
		int attempt = 0;
		
		String PC = "";
		boolean gameOver = false; 
					
		//header text
		JOptionPane.showMessageDialog(null, " Welcome to Eric Says... Game! ");
		
					
		//run while loop until the game is over
		
		while(!gameOver){
		//initialize player choice to avoid unwanted inputs	
		playerChoice = -1;
		// counter
		attempt = attempt + 1;	
		
		//generate a random number for the computer using a function
		randomNumber = generateRandom();
						
		//collect user input as an int from 0 to 20
		
		PC = JOptionPane.showInputDialog("Eric Says...\nPlease Enter a Number From 0 to 20  " );
		
		if (!Pattern.matches("[a-zA-Z]+", PC)) {
				playerChoice = Integer.parseInt(PC);
		
			}
			
			
		if(playerChoice<0||playerChoice>20)
			{
				JOptionPane.showMessageDialog(null, "Eric Says... That is not valid!");
																	
			}
		else{
			
			//run function to find the result
			gameOver = findResult(randomNumber, playerChoice, attempt);	
			
			}
			
		}
		
		
	}
	
				
		//function to generate random number from 0 to 20, inclusive, and return it
	public static int generateRandom() {
			Random rnd = new Random();
			return rnd.nextInt(21);
		}
				
			
		//function to find the result of the game and display picked numbers
	public static boolean findResult(int randomNumber, int playerChoice, int attempt){
				
				if (attempt <= 10){
					if(playerChoice==randomNumber)
					{
						JOptionPane.showMessageDialog(null,"Eric Says...\nYou Guessed!" + "\nYou Said: " + playerChoice + "\nHe Said " + randomNumber  + "\nYou Win!");
						return true;
					}
					else
					{
						JOptionPane.showMessageDialog(null,"Eric Says...\nYou Said: " + playerChoice + "\nHe Said: " + randomNumber + "\nYou lose! Try again!" + "\nAttempts: " + attempt);
						return false;
					}
					}
			   	else{
			   		JOptionPane.showMessageDialog(null,"Eric Says...\nYou Ran out of attempts try again later, bye");
					return true;
			   	}
			}
		}


