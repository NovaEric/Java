
public class Loop {
	
	public static void main(String [] args){
		
		System.out.print("----------------------\n");
		System.out.print("Pattern A  Pattern B             \n");
		System.out.print("----------------------\n");
		for (int i = 0; i < 10; i++){
			
						
			for (int k = 0; k <= 10; k++){
				
				
				if (k <= i){
					System.out.print("+");
				}
				else{
					System.out.print(" ");
					
				}
									
			}
			for (int t = 9; t >= i ; t--){
				
					System.out.print("+");
				
			}
			System.out.print("\n");			
		}
		System.out.print("----------------------\n");
	}
	
}
