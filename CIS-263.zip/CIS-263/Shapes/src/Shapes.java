import javax.swing.JOptionPane;

public class Shapes {

	//array for shapes
	static char shape[][] = new char[50][50];
	
	
	
	public static void main(String[] args) {
		
		
		//header text
		JOptionPane.showMessageDialog(null, " Welcome to Shapes ");
				
		//set gameover to true to stop loop
		boolean gameover = false;
		
		//string for input
		String menuOption = null;
		String menuStar= null;
		
		
		
		//string converted into int for switch statement
		int menuOptionInt = 0;
		int menuStarInt = 0;
		
		
		
		
		//main loop
		do{
			
			//reset variables
			menuOptionInt = 0;
			menuOption = null;
			
			menuStarInt = 0;
			menuStar = null;
			
			
			//show menu and get user input for shape
			menuOption = JOptionPane.showInputDialog("Please select which shape: \n" + "1. Filled Triangle\n" + "2. Filled Star\n" + "3. Filled Square\n" + "4. Bow Tie\n" + "5. Exit\n" );
			menuOptionInt = Integer.parseInt(menuOption);
			
			//validate input for shape
			while (menuOptionInt<1||menuOptionInt>5)
			{
				JOptionPane.showMessageDialog(null, "That is not valid, please enter a number from 1 to 5:");
				menuOption = JOptionPane.showInputDialog("Please select which shape: \n" + "1. Filled Triangle\n" + "2. Filled Star\n" + "3. Filled Square\n" + "4. Bow Tie\n" + "5. Exit\n" );
				menuOptionInt = Integer.parseInt(menuOption);
			}
			
			if(menuOptionInt != 5){
				//show menu and get user input for stars
				menuStar = JOptionPane.showInputDialog("Please enter a number between 1 and 50 for \nthe amount of stars to fill the shape." );
				menuStarInt = Integer.parseInt(menuStar);
				
				//validate input for stars
				while (menuStarInt<1||menuStarInt>=50)
				{
					JOptionPane.showMessageDialog(null, "That is not valid, please enter a number from 1 to 50:");
					menuStar = JOptionPane.showInputDialog("Please enter a number between 1 and 50 for the amount of stars to fill the shape." );
					menuStarInt = Integer.parseInt(menuStar);
				}
			}
			
			//adjust menu choice since array starts at 0
			menuStarInt = menuStarInt - 1;
			
			//clear array
			for(int row = 0; row < menuStarInt; row++)
				for(int col = 0; col < menuStarInt; col++)
					shape[row][col] = ' ';
			
			//select which shape to make
			switch(menuOptionInt){
				case 1:
					filledTriangle(menuStarInt);
					break;
				case 2:
					filledStar(menuStarInt);
					break;
				case 3:
					filledSquare(menuStarInt);
					break;
				case 4:
					BowTie(menuStarInt);
					break;
				case 5:
					gameover = true;
					break;
					
				default:
					break;
			}
			
			//print shape if exit wasn't chosen
			if(!gameover)
				displayShape(menuStarInt);
			
			
		}while(!gameover);

	}
	
	public static void filledTriangle(int star){
 		int row = 0;
		int col = 0;
		
		for(row = 0; row <= star; row++){
			
			for(col = 0; col <= (star - row); col++){
				shape[col][row] = '*';						
			}
			shape[row][col]= '\n';
			
		}
		
	};
	
	public static void filledStar(int star){
		//Need star array fill here
	};

	public static void filledSquare(int star){
		int row = 0;
		int col = 0;
		
		for(row = 0; row <= star; row++){
			
			for(col = 0; col <= star; col++){
				shape[row][col] = '*';
			}
			shape[row][col]= '\n';
		}
		
		
	};

	public static void BowTie(int star){
		//Need bow tie array fill here
		
	};
		
	public static void displayShape(int star){

		StringBuilder showOut = new StringBuilder();
		
		//clear string before
		showOut.setLength(0);
		
		//create a string from the array of char
		for( char[] pos : shape)
			showOut.append(pos);
					
		//print string to message box
		JOptionPane.showMessageDialog(null,showOut);	
		
	};
	
	
}
