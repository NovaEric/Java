import javax.swing.JOptionPane;
import javax.swing.UIManager;

import java.awt.Dimension;
import java.util.Scanner;
public class JavaClass {
	public static void main(String[] args)
	{
		UIManager.put("OptionPane.minimumSize",new Dimension(900,700)); 
		//JOptionPane.showMessageDialog(null, "First Java Dialog");
		//JOptionPane.showMessageDialog(null, "2nd Java Dialog");
		/*int creditDays = 30;
		JOptionPane.showMessageDialog(null, " " + creditDays);
		JOptionPane.showMessageDialog(null, "Every bill is due in" + " " + creditDays + " " + "days");*/
		
		String name, Age, Age2;
		int age, age2, M, D, A, S;
		/*Scanner inputDevice = new Scanner(System.in);
		System.out.print("Please enter your name >> ");
		name = inputDevice.nextLine();
		System.out.print("Please enter your age >> ");
		age = inputDevice.nextInt();*/
		
		name = JOptionPane.showInputDialog(null, "Please enter your Name! ");
		Age = JOptionPane.showInputDialog(null, "Please enter your Age! ");
		Age2 = JOptionPane.showInputDialog(null, "Please enter your Age2! ");
		age = Integer.parseInt(Age);
		age2 = Integer.parseInt(Age2);
		S = age2 - age;
		A = age2 + age;
		M = age2 * age;
		D = age2 / age;
		JOptionPane.showMessageDialog(null, "Your Name is " + name + " and you are " + age + " years old.");
		JOptionPane.showMessageDialog(null, "Both Ages Divide are: " + D);
		JOptionPane.showMessageDialog(null, "Both Ages Multiply are: " + M);
		JOptionPane.showMessageDialog(null, "Both Ages Sustracted are: " + S);
		JOptionPane.showMessageDialog(null, "Both Ages Added are: " + A);
		
		
		
		
	
	}
	

}
