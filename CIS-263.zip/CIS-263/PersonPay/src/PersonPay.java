import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

public class PersonPay {

	//Weekly Payment
	public static double WeeklyPay (double HW, double PR){
		double WP = 0;
		
		WP = HW * PR;
		
		return WP;
	}
	
	//BiWeekly Payment
	public static double BiWeeklyPay(double WP){
		double BWP = 0;
				
		BWP = WP * 2;
		
		return BWP;
	}
	
	//Monthly Payment
	public static double MonthlyPay(double WP){
		double MP = 0;
				
		MP = WP * 4;
		
		return MP;
	}
	
	//Yearly Payment
	public static double YearlyPay(double MP){
		double YP = 0;
				
		YP = MP * 12;
		
		return YP;
	}
	
	//Main Function
	public static void main(String[] args) {
		
		
		//Some code for the Dialog Window Size, TextColor, etc.
		UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Verdana", Font.BOLD, 42)));
		UIManager.put("OptionPane.messageForeground", Color.blue);
		UIManager.put("TextField.font", new FontUIResource(new Font("Verdana", Font.BOLD, 32)));
		UIManager.put("OptionPane.minimumSize",new Dimension(1000,600));
		
		//declaring variables
		double PayRate = 22.50;
		double HourWorked = 0;
		double WeekPay = 0;
		double BiweekPay = 0;
		double MonthPay = 0;
		double YearPay = 0;
		String Fname;
		String Lname;
		String SocialSecurity;
		String Message;
		
		//Encapsulation
		Fname = JOptionPane.showInputDialog("Enter First Name");
		Lname = JOptionPane.showInputDialog("Enter Last Name");
		SocialSecurity = JOptionPane.showInputDialog("Enter Social Security Number");
		HourWorked = Double.parseDouble(JOptionPane.showInputDialog("Enter Hours Worked for the Week"));
		
		WeekPay = WeeklyPay(HourWorked,PayRate);
		BiweekPay = BiWeeklyPay(WeekPay);
		MonthPay = MonthlyPay(WeekPay);
		YearPay = YearlyPay(MonthPay);
		
		
		Message = "First Name: " + Fname +  "\nLast Name: " +
				Lname + "\nSocial Security: " + SocialSecurity + "\nWeekly Pay: " + WeekPay +
				"\nBiWeekly Pay: " + BiweekPay + "\nMonthly Pay: " + MonthPay + "\nYearly Pay: " + YearPay;
		
		//printing
		JOptionPane.showMessageDialog(null, Message);
		
	}

}
