
import java.util.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;


public class RPS {

	public static void main(String[] args) {
		
		// Appearance (Window Size, TextColor, etc.)
		UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Verdana", Font.BOLD, 42)));
		UIManager.put("OptionPane.messageForeground", Color.red);
		UIManager.put("TextField.font", new FontUIResource(new Font("Verdana", Font.BOLD, 32)));
		UIManager.put("OptionPane.minimumSize",new Dimension(1000,600));
					
			//variables
			int randomNumber;
			int playerChoice = 0;
			String PC;
			boolean gameOver = false; 
			
			//header text
			JOptionPane.showMessageDialog(null, " Welcome to Rock, Paper, Scissors ");
			
			//run while loop until the game is over
			while(!gameOver){
				
			//generate a random number for the computer using a function
			randomNumber = generateRandom();
				
			//collect user input as an int from 1 to 3
			PC = JOptionPane.showInputDialog("Please enter a number from 1 to 3 as follows: \n" + "1. Rock\n" + "2. Paper\n" + "3. Scissors\n" );
			
			playerChoice = Integer.parseInt(PC);
					
			//validate input
			while (playerChoice<1||playerChoice>3)
			{
				JOptionPane.showMessageDialog(null, "That is not valid, please enter a number from 1 to 3:");
				PC = JOptionPane.showInputDialog("Please enter a number from 1 to 3 as follows: \n" + "1. Rock\n" + "1. Paper\n" + "1. Scissors\n" );
				playerChoice = Integer.parseInt(PC);
			}
			
			//run function to display the player and computer choices
			displayChoices(randomNumber, playerChoice);
			
			//run function to find the result
			gameOver = findResult(randomNumber, playerChoice);
			
			}
		}
		
		//function to generate random number from 1 to 3, inclusive, and return it
		public static int generateRandom() {
			Random rnd = new Random();
			return rnd.nextInt(4);
		}
		
		//function to display both choices
		public static void displayChoices(int randomNumber, int playerChoice){
			
			if(playerChoice==1)
			{
				JOptionPane.showMessageDialog(null,"You picked rock");
			}
			else if(playerChoice==2)
			{
				JOptionPane.showMessageDialog(null,"You picked paper");
			}
			else
			{
				JOptionPane.showMessageDialog(null,"You picked scissors");
			}
				
			if(randomNumber==1)
			{
				JOptionPane.showMessageDialog(null,"The computer picked rock");
			}
			else if(randomNumber==2)
			{
				JOptionPane.showMessageDialog(null,"The computer picked paper");
			}
			else
			{
				JOptionPane.showMessageDialog(null,"The computer picked scissors");
			}
		}
		
		//function to find the result of the game
		public static boolean findResult(int randomNumber, int playerChoice){
			if(playerChoice==randomNumber)
			{
				JOptionPane.showMessageDialog(null,"Tie, play again");
				return false;
			}
			else if((playerChoice==1 && randomNumber==3)||(playerChoice==2 && randomNumber==1)||(playerChoice==3 && randomNumber==2))
			{
				JOptionPane.showMessageDialog(null,"You win!");
				return true;
			}
			else
			{
				JOptionPane.showMessageDialog(null,"You lose");
				return true;
			}
		}

}
