
import javax.swing.JOptionPane;

public class Distance {

	
	public static void main(String[] args) {
		
		int Speed = 0, Time = 0, Distance = 0;
		
		Speed = Integer.parseInt(JOptionPane.showInputDialog("Enter Speed per Miles"));
		Distance = Integer.parseInt(JOptionPane.showInputDialog("Enter Distance Traveled"));
		
		while (Speed < 1){
			
			Speed = Integer.parseInt(JOptionPane.showInputDialog("Enter Speed per Miles"));
		}
		while (Distance < 1){
			
			Distance = Integer.parseInt(JOptionPane.showInputDialog("Enter Distance Traveled"));
		}
				
		for(int x=0;x<10;x++){
			
			int timetotal = Distance + (x * Speed);
			
		System.out.println((x + 1) + " " + timetotal );
		
		
		}
		
	
		
	}

}
