
public class salary {

}
