import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

public class coinToss {
	public static void main(String[] args){
		
		
		/* Appearance (Window Size, TextColor, etc.)
				UIManager.put("OptionPane.messageFont", new FontUIResource(new Font("Verdana", Font.BOLD, 42)));
				UIManager.put("OptionPane.messageForeground", Color.DARK_GRAY);
				UIManager.put("TextField.font", new FontUIResource(new Font("Verdana", Font.BOLD, 32)));
				UIManager.put("OptionPane.minimumSize",new Dimension(1000,600));*/
				
				
		int toss;
		String UserChoice;
		//Gather User Choice
		UserChoice = JOptionPane.showInputDialog("Enter How Many Times Should The Coin be Tossed! ");
		
		toss = Integer.parseInt(UserChoice);
		
		//Toss the Coin
		for (int i = 0; i <= toss; i++){
			
			randomToss();
						
		}
		
		
		//find results
		if (randomToss() == 1){
			
			UserChoice = "Heads";
		}
		else{
			
			UserChoice = "Tails";
		}
		
		//print results
		
		JOptionPane.showMessageDialog(null, "The Coin Was Tossed " + toss + " Times. ");
		JOptionPane.showMessageDialog(null, "The Result is " + UserChoice);
		
	}
	
	//Random number Function
	public static int randomToss(){
		int Ranber;
		
		Random rnd = new Random();
		if (rnd.nextInt(2) == 1){
			
			Ranber = 2;
		
		}
		else{
				
				Ranber = 1;
			
		}
		
		return Ranber;
		
	}
}
